<div id="primary" class="content-area">
	<div class="primary-inner">
		<div id="content" class="site-content" role="main">
			<?php if( is_page() || is_archive() ) { ?>
			<header class="page-header">
				<h1 class="page-title"><?php _e( 'Question & Answer', 'dw-minion' ); ?></h1>
			</header>
			<?php } ?>
			<div class="dwqa-container">